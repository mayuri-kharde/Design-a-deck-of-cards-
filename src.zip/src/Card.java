public class Card
{
    int faceValue;
    Suit suite;

    Card(int faceValue, Suit suite)
    {
        this.faceValue = faceValue;
        this.suite = suite;
    }
}
