import java.util.List;

public class Player
{
    int id;
    Card card;

    public Player(int id)
    {
        this.id = id;
    }
}
