public enum Suit
{
    SPADE,
    HEART,
    CLUB,
    DIAMOND
}
